import serial.tools.list_ports
from win32api import GetSystemMetrics

# print "Width =", GetSystemMetrics(0)
# print "Height =", GetSystemMetrics(1)
from kivy.config import Config
Config.set('graphics', 'width', GetSystemMetrics(0))#GetSystemMetrics(0)
Config.set('graphics', 'height', GetSystemMetrics(1))#GetSystemMetrics(1))
from kivy.app import App
from kivy.lang import Builder
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.button import Button
from kivy.uix.floatlayout import FloatLayout
from kivy.uix.spinner import Spinner
from kivy.uix.screenmanager import ScreenManager, Screen, FadeTransition
from kivy.properties import ListProperty, ObjectProperty
from random import shuffle


from kivy.uix.behaviors import ButtonBehavior

from kivy.clock import Clock
from kivy.animation import Animation
from kivy.properties import (
    NumericProperty, ListProperty, ObjectProperty, DictProperty)
from kivy.app import App

from functools import partial
from copy import copy


##TODO:COM available  Green  if  it's  out   becomes  Red
##TODO : refresh  comports
#TODO: Graph
#TODO: Smilies
####################################################  Variables ##############################################*
COM=''  ## selected COM PORT
COM_Connected=0   ##variable To  get the status  of the connected COm
###################################################
#####


from mapview import MapView, MapSource
Builder.load_string('''

############################Modern Buton
#:import pi math.pi
#:import cos math.cos
#:import sin math.sin
#:import V kivy.vector.Vector
<ModernMenu>:
    canvas.before:
        Color:
            rgba: 1, 0, 0, .4
        Ellipse:
            pos: self.center_x - self.radius, self.center_y - self.radius
            size: self.radius * 2, self.radius * 2
            angle_start: 0
            angle_end: self.circle_progress * 360 * self.creation_direction
        Color:
            rgba: self.color
        Line:
            circle:
                (
                self.center_x, self.center_y,
                self.radius, 0, self.circle_progress * 360 * self.creation_direction
                )
            width: self.line_width
    on_touch_down:
        V(args[1].pos).distance(self.center) < self.radius and (
        self.back() if self.choices_history else self.dismiss())
<ModernMenuLabel>:
    size: self.texture_size
    padding: 5, 5
    on_press: self.callback and self.callback(self)
    canvas.before:
        Color:
            rgba: .1, .4, .4, .9
        Rectangle:
            pos: self.pos
            size: self.size
        Line:
            points:
                (
                self.center_x, self.center_y,
                self.parent.center_x + cos(
                self.opacity * self.index * 2 * pi / self.siblings
                ) * self.parent.radius,
                self.parent.center_y + sin(
                self.opacity * self.index * 2 * pi / self.siblings
                ) * self.parent.radius
                ) if self.parent else []
            width: self.parent.line_width if self.parent else 1
    center:
        (
        self.parent.center_x +
        cos(self.opacity * self.index * 2 * pi / self.siblings) * self.radius,
        self.parent.center_y +
        sin(self.opacity * self.index * 2 * pi / self.siblings) * self.radius
        ) if (self.size and self.parent and self.parent.children) else (0, 0)


############################ END of Modern Buton
<PM>:
    name: 'map'
    
    #:import sys sys
    
    MapView:
        lat: 35.82265383
        lon: 10.56091650
        zoom: 13
        map_source: MapSource(sys.argv[1], attribution="") if len(sys.argv) > 1 else "osm"
        Button:
            on_release: app.root.current='first' 
            text: "MAIN"
            size_hint : .06,.1
            pos:  root.width/10,root.height/10
        MapMarkerPopup:
            lat: 35.82265383
            lon: 10.56091650
            popup_size: dp(230), dp(130)
            



<MyThing>:

    name: 'Spinner'
    fullscreen: True

    Spinner:
        id: spinner_1
        text: 'Select'
        values: app.connected
        on_text: root.updateSubSpinner(spinner_1.text)
        size_hint_y: None
        height: '48dp'


    Button:
        on_release: app.root.current='first' if app.COM_Connected1==1 else 'Spinner'
        text: "Connect"
        size_hint : .06,.1
        pos:  root.width/2,root.height/2

<FirstScreen>:
    name: 'first'
    Button:
        on_release: app.root.current='map'
        text: "MAP"
        size_hint : .06,.1
        pos:  root.width-100,root.height-100

    Label:
        id: boo
        text:root.textvar
        color: 0,0,1,1
        size_hint: (.2,.2)
        pos_hint: {"x":0.1, "y":0.85}


    # canvas:
    #     Color:
    #         rgba: self.color
    #     Rectangle:
    #         id:rect
    #         pos: self.width / 18,self.height / 1.1
    #         size: self.width / 20., self.height /10
    MenuSpawner:
        timeout: .8
        menu_args:
            dict(
            creation_direction=-1,
            radius=30,
            creation_timeout=.4,
            choices=[
            dict(text='submenu 1', index=1, callback=app.callback1),
            dict(text='action 1', index=2, callback=app.callback2),
            dict(text='action 2', index=3, callback=app.callback3),
            dict(text='submenu 2', index=4, callback=app.callback4),
            dict(text='action 3', index=5, callback=app.callback5),
            ])



''')
#####################################################Gauge########
import kivy
kivy.require('1.7.1')
from kivy.config import Config
from kivy.app import App
from kivy.clock import Clock
from kivy.properties import NumericProperty
from kivy.properties import StringProperty
from kivy.properties import BoundedNumericProperty
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.widget import Widget
from kivy.uix.scatter import Scatter
from kivy.uix.image import Image
from kivy.uix.label import Label
from kivy.uix.progressbar import ProgressBar
from numpy import arange, sin, pi
import sqlite3
import serial
db = sqlite3.connect('IOT.db') #### MYSQL DATABASE
import time
cursor = db.cursor()
try:
    cursor.execute("DROP TABLE TST;")
except:
    pass

###############################################
###############################################
cursor.execute('''CREATE TABLE TST
             (name_id INTEGER PRIMARY KEY,X_r BIGINT,Y_r BIGINT)''')   ### Database Table




txtvar=''


##########Modern Button
def dist((x1, y1), (x2, y2)):
    return ((x1 - x2) ** 2 + (y1 - y2) ** 2) ** 5


class ModernMenuLabel(ButtonBehavior, Label):
    index = NumericProperty(0)
    radius = NumericProperty(100)
    siblings = NumericProperty(1)
    callback = ObjectProperty(None)

    def on_parent(self, *args):
        if self.parent:
            self.parent.bind(children=self.update_siblings)

    def update_siblings(self, *args):
        if self.parent:
            self.siblings = max(0, len(self.parent.children))
        else:
            self.siblings = 1
class PM(Screen):
    pass


# class PM(Screen):
#     def __init__(self,):
#
#         super(PM, self).__init__()
#         self.add_widget(AMPS())

class ModernMenu(Widget):
    radius = NumericProperty(50)
    circle_width = NumericProperty(5)
    line_width = NumericProperty(2)
    color = ListProperty([.3, .3, .3, 1])
    circle_progress = NumericProperty(0)
    creation_direction = NumericProperty(1)
    creation_timeout = NumericProperty(1)
    choices = ListProperty([])
    item_cls = ObjectProperty(ModernMenuLabel)
    item_args = DictProperty({'opacity': 0})
    animation = ObjectProperty(Animation(opacity=1, d=.5))
    choices_history = ListProperty([])

    def start_display(self, touch):
        touch.grab(self)
        a = Animation(circle_progress=1, d=self.creation_timeout)
        a.bind(on_complete=self.open_menu)
        touch.ud['animation'] = a
        a.start(self)

    def open_menu(self, *args):
        self.clear_widgets()
        for i in self.choices:
            kwargs = copy(self.item_args)
            kwargs.update(i)
            ml = self.item_cls(**kwargs)
            self.animation.start(ml)
            self.add_widget(ml)

    def open_submenu(self, choices, *args):
        self.choices_history.append(self.choices)
        self.choices = choices
        self.open_menu()

    def back(self, *args):
        self.choices = self.choices_history.pop()
        self.open_menu()

    def on_touch_move(self, touch, *args):
        if (
            touch.grab_current == self and
            dist(touch.pos, touch.opos) > self.radius and
            self.parent and
            self.circle_progress < 1
        ):
            self.parent.remove_widget(self)

        return super(ModernMenu, self).on_touch_move(touch, *args)

    def on_touch_up(self, touch, *args):
        if (
            touch.grab_current == self and
            self.parent and
            self.circle_progress < 1
        ):
            self.parent.remove_widget(self)
        return super(ModernMenu, self).on_touch_up(touch, *args)

    def dismiss(self):
        a = Animation(opacity=0)
        a.bind(on_complete=self._remove)
        a.start(self)

    def _remove(self, *args):
        if self.parent:
            self.parent.remove_widget(self)


class MenuSpawner(Widget):
    timeout = NumericProperty(0.1)
    menu_cls = ObjectProperty(ModernMenu)
    cancel_distance = NumericProperty(10)
    menu_args = DictProperty({})

    def on_touch_down(self, touch, *args):
        t = partial(self.display_menu, touch)
        touch.ud['menu_timeout'] = t
        Clock.schedule_once(t, self.timeout)
        return super(MenuSpawner, self).on_touch_down(touch, *args)

    # def on_touch_move(self, touch, *args):   # reactive it after  removing  the progress bar  test for gauge
    #     if (
    #         touch.ud['menu_timeout'] and
    #         dist(touch.pos, touch.opos) > self.cancel_distance
    #     ):
    #         Clock.unschedule(touch.ud['menu_timeout'])
    #     return super(MenuSpawner, self).on_touch_move(touch, *args)

    def on_touch_up(self, touch, *args):
        if touch.ud.get('menu_timeout'):
            Clock.unschedule(touch.ud['menu_timeout'])
        return super(MenuSpawner, self).on_touch_up(touch, *args)

    def display_menu(self, touch, dt):
        menu = self.menu_cls(center=touch.pos, **self.menu_args)
        self.add_widget(menu)
        menu.start_display(touch)
######END of modern Button





class Gauge(Widget):
    '''
    Gauge class

    '''

    unit = NumericProperty(1.8)
    value = BoundedNumericProperty(0, min=0, max=100, errorvalue=0)
    file_gauge = StringProperty("cadran.png")
    file_needle = StringProperty("needle.png")
    size_gauge = BoundedNumericProperty(128, min=128, max=256, errorvalue=128)
    size_text = NumericProperty(10)

    def __init__(self, **kwargs):
        super(Gauge, self).__init__(**kwargs)

        self._gauge = Scatter(
            size=(self.size_gauge, self.size_gauge),
            do_rotation=False,
            do_scale=False,
            do_translation=False
        )

        _img_gauge = Image(source=self.file_gauge, size=(self.size_gauge,
                                                         self.size_gauge))

        self._needle = Scatter(
            size=(self.size_gauge, self.size_gauge),
            do_rotation=False,
            do_scale=False,
            do_translation=False
        )

        _img_needle = Image(source=self.file_needle, size=(self.size_gauge,
                                                           self.size_gauge))

        self._glab = Label(font_size=self.size_text, markup=True)
        self._progress = ProgressBar(max=100, height=20, value=self.value)

        self._gauge.add_widget(_img_gauge)
        self._needle.add_widget(_img_needle)

        self.add_widget(self._gauge)
        self.add_widget(self._needle)
        self.add_widget(self._glab)
        self.add_widget(self._progress)

        self.bind(pos=self._update)
        self.bind(size=self._update)
        self.bind(value=self._turn)

    def _update(self, *args):
        '''
        Update gauge and needle positions after sizing or positioning.

        '''
        self._gauge.pos = self.pos
        self._needle.pos = (self.x, self.y)
        self._needle.center = self._gauge.center
        self._glab.center_x = self._gauge.center_x
        self._glab.center_y = self._gauge.center_y + (self.size_gauge / 4)
        self._progress.x = self._gauge.x
        self._progress.y = self._gauge.y + (self.size_gauge / 4)
        self._progress.width = self.size_gauge

    def _turn(self, *args):
        '''
        Turn needle, 1 degree = 1 unit, 0 degree point start on 50 value.

        '''
        self._needle.center_x = self._gauge.center_x
        self._needle.center_y = self._gauge.center_y
        self._needle.rotation = (50 * self.unit) - (self.value * self.unit)
        self._glab.text = "[b]{0:.0f}[/b]".format(self.value)
        self._progress.value = self.value


################################ END of Gauge Class


gauge_value=0
colorid=(1,0,0,1)
class FirstScreen(Screen):
    textvar = StringProperty()
    r = NumericProperty(0)
    def __init__(self,):
        global colorid
        self.color=colorid
        from kivy.uix.slider import Slider
        super(FirstScreen, self).__init__()
        self.add_widget(MyGraph())
        self.add_widget(MyGraph1())
        self.add_widget(MyGraph2())
        self.add_widget(MyGraph4())
        #self.add_widget(Gauge())
        box = BoxLayout(orientation='vertical', spacing=10, padding=10)
        self.gauge = Gauge(value=50, size_gauge=256, size_text=9)
        self.gauge_ = Gauge(value=50, size_gauge=256, size_text=19)
        self.gauge_1 = Gauge(value=50, size_gauge=256, size_text=19)
        self.gauge1 = Gauge(value=50, size_gauge=256, size_text=9)
        box.add_widget(self.gauge)
        box.add_widget(self.gauge_)
        box.add_widget(self.gauge1)
        box.add_widget(self.gauge_1)

        #self.s = Slider(min=0, max=100, value=50)
        #self.s.bind(value=self.test_)
        #box.add_widget(self.s)

        #self.s1 = Slider(min=0, max=100, value=50)
        #self.s1.bind(value=self.test_)
        #box.add_widget(self.s1)
        self.add_widget(box)
        #self.add_widget(Image(source='smilseys/1_burned.png'))

        Clock.schedule_interval(self.test, 0.5)





    def test(self,dt):
        global COM_Connected
        global txtvar
        if (COM_Connected==1):
#            self.canvas.clear('rect')
            with self.canvas.after:
                self.color = (0, 1, 0, 1)

        else:
            with self.canvas.after:
                self.color = (1, 0, 0, 1)
        global gauge_value
        self.gauge_.value = gauge_value
        self.gauge.value = gauge_value
        self.gauge_1.value = gauge_value
        self.gauge1.value = gauge_value
        print "comconnected"+str(COM_Connected)

        self.textvar=txtvar


    #    print(self.s.value)

    # def test_(self,*ars):
    #     self.gauge_.value = self.s1.value
    #     # print(self.s.value)
###Graph screen
#TODO : when  pressed  connect  and  no  com selected   --> make sure to  select comport  before  clicking on  connect
X_r=1
class MyGraph(Widget):
    global curve_pts
    global txtvar
    kv = 0
    from graph import Graph, MeshLinePlot
    plot = MeshLinePlot(color=[1, 0, 0, 1])

    def __init__(self):
        global array
        super(MyGraph, self).__init__()
        from graph import Graph, MeshLinePlot
        self.graph1 = Graph(xlabel='X', ylabel='Y', x_ticks_minor=5,
                       x_ticks_major=100, y_ticks_major=100,
                       y_grid_label=True, x_grid_label=True, padding=5,
                       x_grid=True, y_grid=True, xmin=-0, xmax=500, ymin=0, ymax=500,size=(GetSystemMetrics(0)/2,GetSystemMetrics(1)/4),pos=(GetSystemMetrics(0)/2,0))

        self.plot.points = [(x, sin(x / 10.)) for x in range(0, 101)]
        self.graph1.add_plot(self.plot)
        #print (graph1)

        Clock.schedule_interval(self.get_v, 0.5)
        self.add_widget(self.graph1)

    def get_v(self, dt):
        global kv
        global graph
        global id
        #print len(self.plot.points)
        global COM_Connected
        global ser


        if (COM_Connected == 1):
            print "connected"



            db.commit()
            while ser.in_waiting:
                global Y_r# Or: while ser.inWaiting():
                global X_r
                val = ser.readline()
                cursor.execute('''INSERT INTO TST(X_r,Y_r)
                                      VALUES(?,?)''', (val, X_r))
                X_r =X_r +10;
                cursor.execute("SELECT * FROM TST")
                rows = cursor.fetchall()
                print rows
                ids = len(rows)
                print ids
                x_cord = rows[ids - 1][0]  # id
                y_cord = float(rows[ids - 1][1])  # flow
                global gauge_value
                gauge_value=y_cord/5
                if ids != id:
                    id = ids
                    self.plot.points.append((x_cord, y_cord))
                print "grrrr"
                max_val=(max(map(lambda x: x[1], rows)))

                self.graph1.xmax=max_val
                self.graph1.ymax = max_val

                if len(self.plot.points) >= 100:
                    self.plot.points = []
        # curve_pts.append(kv,sin(kv))

        # print rows[ids-1][1]

        # try:
        #     print "s"
        #     db.commit()
        #     cursor.execute("SELECT * FROM SBC_T")
        #     rows = cursor.fetchall()
        #     ids = cursor.rowcount
        #     print "ids", ids, id
        #     x_cord = rows[ids - 1][0]  # id
        #     y_cord = rows[ids - 1][1]  # flow
        #     print "coords", x_cord, y_cord
        #
        #     if ids != id:
        #         id = ids
        #         self.plot.points.append((x_cord, y_cord))

        # except:
        #     print "empty Tab"
        #
        # ########;)
        #
        # if len(self.plot.points) >= 100:
        #     self.plot.points = []
        #     ### It's working  but  you need to figure out  how  to  change xmax
        #
        #     kv = 0
        #
        # kv = kv + 1
        # # print kv



class MyGraph1(Widget):
    global curve_pts
    global txtvar
    kv = 0
    from graph import Graph, MeshLinePlot
    plot = MeshLinePlot(color=[1, 0, 0, 1])

    def __init__(self):
        global array
        super(MyGraph1, self).__init__()
        from graph import Graph, MeshLinePlot
        self.graph1 = Graph(xlabel='X', ylabel='Y', x_ticks_minor=5,
                       x_ticks_major=100, y_ticks_major=100,
                       y_grid_label=True, x_grid_label=True, padding=5,
                       x_grid=True, y_grid=True, xmin=-0, xmax=500, ymin=0, ymax=500,size=(GetSystemMetrics(0)/2,GetSystemMetrics(1)/4),pos=(GetSystemMetrics(0)/2,200))

        self.plot.points = [(x, sin(x / 10.)) for x in range(0, 101)]
        self.graph1.add_plot(self.plot)
        #print (graph1)

        Clock.schedule_interval(self.get_v, 0.5)
        self.add_widget(self.graph1)

    def get_v(self, dt):
        global kv
        global graph
        global id
        #print len(self.plot.points)
        global COM_Connected
        global ser


        if (COM_Connected == 1):
            print "connected"



            db.commit()
            while ser.in_waiting:
                global Y_r# Or: while ser.inWaiting():
                global X_r
                val = ser.readline()
                cursor.execute('''INSERT INTO TST(X_r,Y_r)
                                      VALUES(?,?)''', (val, X_r))
                X_r =X_r +10;
                cursor.execute("SELECT * FROM TST")
                rows = cursor.fetchall()
                print rows
                ids = len(rows)
                print ids
                x_cord = rows[ids - 1][0]  # id
                y_cord = float(rows[ids - 1][1])  # flow
                global gauge_value
                gauge_value=y_cord/5
                if ids != id:
                    id = ids
                    self.plot.points.append((x_cord, y_cord))
                print "grrrr"
                max_val=(max(map(lambda x: x[1], rows)))

                self.graph1.xmax=max_val
                self.graph1.ymax = max_val

                if len(self.plot.points) >= 100:
                    self.plot.points = []
        # curve_pts.append(kv,sin(kv))

        # print rows[ids-1][1]

        # try:
        #     print "s"
        #     db.commit()
        #     cursor.execute("SELECT * FROM SBC_T")
        #     rows = cursor.fetchall()
        #     ids = cursor.rowcount
        #     print "ids", ids, id
        #     x_cord = rows[ids - 1][0]  # id
        #     y_cord = rows[ids - 1][1]  # flow
        #     print "coords", x_cord, y_cord
        #
        #     if ids != id:
        #         id = ids
        #         self.plot.points.append((x_cord, y_cord))

        # except:
        #     print "empty Tab"
        #
        # ########;)
        #
        # if len(self.plot.points) >= 100:
        #     self.plot.points = []
        #     ### It's working  but  you need to figure out  how  to  change xmax
        #
        #     kv = 0
        #
        # kv = kv + 1
        # # print kv


class MyGraph2(Widget):
    global curve_pts
    global txtvar
    kv = 0
    from graph import Graph, MeshLinePlot
    plot = MeshLinePlot(color=[1, 0, 0, 1])

    def __init__(self):
        global array
        super(MyGraph2, self).__init__()
        from graph import Graph, MeshLinePlot
        self.graph1 = Graph(xlabel='X', ylabel='Y', x_ticks_minor=5,
                       x_ticks_major=100, y_ticks_major=100,
                       y_grid_label=True, x_grid_label=True, padding=5,
                       x_grid=True, y_grid=True, xmin=-0, xmax=500, ymin=0, ymax=500,size=(GetSystemMetrics(0)/2,GetSystemMetrics(1)/4),pos=(GetSystemMetrics(0)/2,400))

        self.plot.points = [(x, sin(x / 10.)) for x in range(0, 101)]
        self.graph1.add_plot(self.plot)
        #print (graph1)

        Clock.schedule_interval(self.get_v, 0.5)
        self.add_widget(self.graph1)

    def get_v(self, dt):
        global kv
        global graph
        global id
        #print len(self.plot.points)
        global COM_Connected
        global ser


        if (COM_Connected == 1):
            print "connected"



            db.commit()
            while ser.in_waiting:
                global Y_r# Or: while ser.inWaiting():
                global X_r
                val = ser.readline()
                cursor.execute('''INSERT INTO TST(X_r,Y_r)
                                      VALUES(?,?)''', (val, X_r))
                X_r =X_r +10;
                cursor.execute("SELECT * FROM TST")
                rows = cursor.fetchall()
                print rows
                ids = len(rows)
                print ids
                x_cord = rows[ids - 1][0]  # id
                y_cord = float(rows[ids - 1][1])  # flow
                global gauge_value
                gauge_value=y_cord/5
                if ids != id:
                    id = ids
                    self.plot.points.append((x_cord, y_cord))
                print "grrrr"
                max_val=(max(map(lambda x: x[1], rows)))

                self.graph1.xmax=max_val
                self.graph1.ymax = max_val

                if len(self.plot.points) >= 100:
                    self.plot.points = []
        # curve_pts.append(kv,sin(kv))

        # print rows[ids-1][1]

        # try:
        #     print "s"
        #     db.commit()
        #     cursor.execute("SELECT * FROM SBC_T")
        #     rows = cursor.fetchall()
        #     ids = cursor.rowcount
        #     print "ids", ids, id
        #     x_cord = rows[ids - 1][0]  # id
        #     y_cord = rows[ids - 1][1]  # flow
        #     print "coords", x_cord, y_cord
        #
        #     if ids != id:
        #         id = ids
        #         self.plot.points.append((x_cord, y_cord))

        # except:
        #     print "empty Tab"
        #
        # ########;)
        #
        # if len(self.plot.points) >= 100:
        #     self.plot.points = []
        #     ### It's working  but  you need to figure out  how  to  change xmax
        #
        #     kv = 0
        #
        # kv = kv + 1
        # # print kv


class MyGraph4(Widget):
    global curve_pts
    global txtvar
    kv = 0
    from graph import Graph, MeshLinePlot
    plot = MeshLinePlot(color=[1, 0, 0, 1])

    def __init__(self):
        global array
        super(MyGraph4, self).__init__()
        from graph import Graph, MeshLinePlot
        self.graph1 = Graph(xlabel='X', ylabel='Y', x_ticks_minor=5,
                       x_ticks_major=100, y_ticks_major=100,
                       y_grid_label=True, x_grid_label=True, padding=5,
                       x_grid=True, y_grid=True, xmin=-0, xmax=500, ymin=0, ymax=500,size=(GetSystemMetrics(0)/2,GetSystemMetrics(1)/4),pos=(GetSystemMetrics(0)/2,600))

        self.plot.points = [(x, sin(x / 10.)) for x in range(0, 101)]
        self.graph1.add_plot(self.plot)
        #print (graph1)

        Clock.schedule_interval(self.get_v, 0.5)
        self.add_widget(self.graph1)

    def get_v(self, dt):
        global kv
        global graph
        global id
        #print len(self.plot.points)
        global COM_Connected
        global ser


        if (COM_Connected == 1):
            print "connected"



            db.commit()
            while ser.in_waiting:
                global Y_r# Or: while ser.inWaiting():
                global X_r
                val = ser.readline()
                cursor.execute('''INSERT INTO TST(X_r,Y_r)
                                      VALUES(?,?)''', (val, X_r))
                X_r =X_r +10;
                cursor.execute("SELECT * FROM TST")
                rows = cursor.fetchall()
                print rows
                ids = len(rows)
                print ids
                x_cord = rows[ids - 1][0]  # id
                y_cord = float(rows[ids - 1][1])  # flow
                global gauge_value
                gauge_value=y_cord/5
                if ids != id:
                    id = ids
                    self.plot.points.append((x_cord, y_cord))
                print "grrrr"
                max_val=(max(map(lambda x: x[1], rows)))

                self.graph1.xmax=max_val
                self.graph1.ymax = max_val

                if len(self.plot.points) >= 100:
                    self.plot.points = []
        # curve_pts.append(kv,sin(kv))

        # print rows[ids-1][1]

        # try:
        #     print "s"
        #     db.commit()
        #     cursor.execute("SELECT * FROM SBC_T")
        #     rows = cursor.fetchall()
        #     ids = cursor.rowcount
        #     print "ids", ids, id
        #     x_cord = rows[ids - 1][0]  # id
        #     y_cord = rows[ids - 1][1]  # flow
        #     print "coords", x_cord, y_cord
        #
        #     if ids != id:
        #         id = ids
        #         self.plot.points.append((x_cord, y_cord))

        # except:
        #     print "empty Tab"
        #
        # ########;)
        #
        # if len(self.plot.points) >= 100:
        #     self.plot.points = []
        #     ### It's working  but  you need to figure out  how  to  change xmax
        #
        #     kv = 0
        #
        # kv = kv + 1
        # # print kv


#########End  graph screen
#########End  graph screen

class MyThing(Screen):
    def __init__(self):
        super(MyThing, self).__init__()
        #Clock.schedule_interval(self.Serial_read, .01)

    def updateSubSpinner(self, text):
        global COM
        global COM_Connected
        global ser
        COM=text
        #print COM
        try:
            ser = serial.Serial(
                port=COM,
                baudrate=9600,
                parity=serial.PARITY_NONE,
                stopbits=serial.STOPBITS_ONE,
                bytesize=serial.EIGHTBITS,
                timeout=0)

            data = ser.readline()
            #print data
            COM_Connected=1
            print("connected to: " + ser.portstr)
        except:
            COM_Connected=0
            print "LOST CONNECTION"





    def Serial_read(self,dt):
            global COM_Connected
            global ser
            if (COM_Connected==1):
                data = ser.readline()
                #print data

            else :
                pass




class Pain_Meter(App):
    COM_Connected1=0
    corlorid=(1,0,1,1)
    value=''



    def build(self):
        comlist = serial.tools.list_ports.comports()
        self.connected = []  ###  variable  used  for  spinner  to select COMPORTS //starting the GUI
        for element in comlist: ###  rethink  of refresh
            self.connected.append(element.device)

        self.root = ScreenManager()
        self.s_screen=FirstScreen()
        self.root.add_widget(MyThing())
        self.root.add_widget(PM())
        self.root.add_widget(self.s_screen)
        Clock.schedule_interval(self.test_con, 1)
        return self.root

    def callback1(self, *args):
            print "test 1"
            args[0].parent.open_submenu(
                choices=[
                    dict(text='action 1', index=1, callback=self.callback2),
                    dict(text='action 2', index=2, callback=self.callback2),
                    dict(text='action 3', index=3, callback=self.callback2),
                ])

    def callback2(self, *args):
            print "test 2"
            args[0].parent.dismiss()

    def callback3(self, *args):
            print "test 3"
            args[0].parent.dismiss()

    def callback4(self, *args):
            print "test 4"
            args[0].parent.open_submenu(
                choices=[
                    dict(text='hey', index=1, callback=self.callback2),
                    dict(text='oh', index=2, callback=self.callback2),
                ])

    def callback5(self, *args):
            print "test 5"
            args[0].parent.dismiss()


    def test_con(self,dt):
        global COM_Connected
        global COM
        global txtvar
        self.COM_Connected1=COM_Connected
        if COM_Connected:

            txtvar='Connected to '+COM

        else :
            txtvar = 'Disconnected'
            #self.root.get_screen('first').ids.grid.add_widget(i)





if __name__ == "__main__":
    Pain_Meter().run()
